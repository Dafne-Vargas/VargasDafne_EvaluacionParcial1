/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemaregistro;

/**
 *
 * @author Duoc
 */
public class Docente {
    String rut;
    String nombre;
    String nroDocente;
    Sede sede;

    public Docente(String rut, String nombre, String nroDocente, String fechaIngreso, Sede sede) {
        this.rut = rut;
        this.nombre = nombre;
        this.nroDocente = nroDocente;
        this.sede = sede;
    }



    public void mostrar() {
        System.out.println("Docente: " + nombre + " | RUT: " + rut + " | Nº Docente: " + nroDocente);
        sede.mostrar();
    }
}
