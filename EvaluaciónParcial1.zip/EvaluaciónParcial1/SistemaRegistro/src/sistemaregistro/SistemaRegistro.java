/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistemaregistro;
import java.util.Scanner;
/**
 *
 * @author Duoc
 */

public class SistemaRegistro {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
            Scanner sc = new Scanner(System.in);
            Estudiante estudiante = null;
            Docente docente = null;
            Asignatura asignatura = null;

        OUTER:
        while (true) {
            System.out.println("\n=== SISTEMA DE REGISTRO DE ASIGNATURAS ===");
            System.out.println("1. Ingresar Estudiante");
            System.out.println("2. Ingresar Docente");
            System.out.println("3. Ingresar Asignatura");
            System.out.println("4. Calcular Resultados");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");
            int opcion = sc.nextInt();
            sc.nextLine();
            switch (opcion) {
                case 1 ->                     {
                        System.out.println("--- INGRESO DE ESTUDIANTE ---");
                        System.out.print("RUT: ");
                        String rut = sc.nextLine();
                        System.out.print("Nombre: ");
                        String nombre = sc.nextLine();
                        System.out.print("Edad: ");
                        int edad = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Fecha nacimiento (AAAA-MM-DD): ");
                        String fecha = sc.nextLine();
                        estudiante = new Estudiante(rut, nombre, edad, fecha);
                        System.out.println("Estudiante registrado.");
                    }
                case 2 ->                     {
                        System.out.println("--- INGRESO DE DOCENTE ---");
                        System.out.print("RUT: ");
                        String rut = sc.nextLine();
                        System.out.print("Nombre: ");
                        String nombre = sc.nextLine();
                        System.out.print("Nº Docente: ");
                        String nro = sc.nextLine();
                        System.out.print("Fecha ingreso (AAAA-MM-DD): ");
                        String fecha = sc.nextLine();
                        System.out.print("Nº Sede: ");
                        String nroSede = sc.nextLine();
                        System.out.print("Nombre Sede: ");
                        String nombreSede = sc.nextLine();
                        System.out.print("Comuna: ");
                        String comuna = sc.nextLine();
                        Sede sede = new Sede(nroSede, nombreSede, comuna);
                        docente = new Docente(rut, nombre, nro, fecha, sede);
                        System.out.println("Docente registrado.");
                    }
                case 3 ->                     {
                        if (estudiante == null || docente == null) {
                            System.out.println("Debe ingresar primero estudiante y docente.");
                            continue;
                        }       System.out.println("--- INGRESO DE ASIGNATURA ---");
                        System.out.print("Código: ");
                        String codigo = sc.nextLine();
                        System.out.print("Nombre: ");
                        String nombre = sc.nextLine();
                        System.out.print("Nota 1: ");
                        double n1 = sc.nextDouble();
                        System.out.print("Nota 2: ");
                        double n2 = sc.nextDouble();
                        System.out.print("Nota 3: ");
                        double n3 = sc.nextDouble();
                        asignatura = new Asignatura(codigo, nombre, estudiante, docente, n1, n2, n3);
                        System.out.println("Asignatura registrada.");
                    }
                case 4 -> {
                    if (asignatura == null) {
                        System.out.println("Debe ingresar una asignatura primero.");
                        continue;
                    }   asignatura.mostrarNotas();
                    System.out.print("Ingrese nota de examen: ");
                    double examen = sc.nextDouble();
                    String estado = asignatura.calcularFinal(examen);
                    System.out.println("Estado final: " + estado);
                    }
                case 5 -> {
                    System.out.println("Saliendo del sistema...");
                    break OUTER;
                    }
                default -> System.out.println("Opción inválida.");
            }
        }
    }
}

