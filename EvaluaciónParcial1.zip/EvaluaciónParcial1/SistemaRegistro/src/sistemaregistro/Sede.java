/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemaregistro;

/**
 *
 * @author Duoc
 */
public class Sede {
    String nroSede;
    String nombre;
    String comuna;

    public Sede(String nroSede, String nombre, String comuna) {
        this.nroSede = nroSede;
        this.nombre = nombre;
        this.comuna = comuna;
    }

    public void mostrar() {
        System.out.println("Sede: " + nombre + " | Comuna: " + comuna);
    }
}  

