/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemaregistro;

/**
 *
 * @author Duoc
 */
public class Estudiante {
    String rut;
    String nombre;
    int edad;
    String fechaNacimiento;

    public Estudiante(String rut, String nombre, int edad, String fechaNacimiento) {
        this.rut = rut;
        this.nombre = nombre;
        this.edad = edad;
        this.fechaNacimiento = fechaNacimiento;
    }

    public void mostrar() {
        System.out.println("Estudiante: " + nombre + " | RUT: " + rut + " | Edad: " + edad);
    }

}