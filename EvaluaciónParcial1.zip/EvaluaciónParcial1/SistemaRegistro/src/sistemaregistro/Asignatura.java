/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemaregistro;

/**
 *
 * @author Duoc
 */
public class Asignatura {
    String codigo;
    String nombre;
    Estudiante estudiante;
    Docente docente;
    double nota1, nota2, nota3;

    public Asignatura(String codigo, String nombre, Estudiante estudiante, Docente docente,double nota1, double nota2, double nota3) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.estudiante = estudiante;
        this.docente = docente;
        this.nota1 = nota1;
        this.nota2 = nota2;
        this.nota3 = nota3;
    }

    public double calcularPresentacion() {
        return nota1 * 0.4 + nota2 * 0.4 + nota3 * 0.2;
    }

    public boolean estaEximido() {
        return calcularPresentacion() >= 5.5;
    }

    public String calcularFinal(double examen) {
        double notaFinal = calcularPresentacion() * 0.7 + examen * 0.3;
        return notaFinal >= 4.5 ? "Aprobado" : "Reprobado";
    }



    public void mostrarNotas() {
        System.out.println("Asignatura: " + nombre + " | Código: " + codigo);
        System.out.println("Notas: " + nota1 + ", " + nota2 + ", " + nota3);
        System.out.println("Nota de presentación: " + calcularPresentacion());
        System.out.println("¿Eximido?: " + (estaEximido() ? "Sí" : "No"));
    }
}

